﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bs.AutoCredito.Comun
{
    public class Constantes
    {
        public const string CadenaConexionBsCredito = "BsCredito";
        public const string spi_crear_operacion_cartera = "spi_crear_operacion_cartera";
        public const string sps_generar_tabla_amortizacion = "sps_generar_tabla_amortizacion";
        public const string spu_actualizar_saldo_cuota = "spu_actualizar_saldo_cuota";
        public const string sps_consultar_cuota_pendiente = "sps_consultar_cuota_pendiente";

    }
}
