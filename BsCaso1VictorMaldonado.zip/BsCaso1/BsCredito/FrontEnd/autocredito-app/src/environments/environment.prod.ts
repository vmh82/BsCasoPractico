export const environment = {
  production: false,
  HOST: 'http://192.168.100.6/BsAutoCredito.Api/api',
};
