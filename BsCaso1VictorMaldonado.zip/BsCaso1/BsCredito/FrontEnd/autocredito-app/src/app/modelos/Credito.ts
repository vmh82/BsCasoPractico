export class Credito{
  nombresCliente:string;
  apellidosCliente:string;
  identificacion:string;
  montoSolicitado:any;
  plazo:number;
}
