export class Parametros{
  desgravamen:any;
  interes:any;
  plazo:[];
}
