export class TablaAmortizacion{
  idTablaAmortizacion:number;
  idOperacionCartera:string;
  numeroCuota:number;
  fechaPago:string;
  capital:any;
  interes:any;
  cuotaTotal:any;
  saldo:any;
  montoPago:any;
  diasVencidos:any;
  mora:any;

}
